-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-02-2026 a las 04:54:18
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `heladeria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bodega`
--

CREATE TABLE `bodega` (
  `Id_Bodega` int(11) NOT NULL,
  `Nombre_Bodega` varchar(45) NOT NULL,
  `Ubicacion` varchar(45) NOT NULL,
  `Estado` enum('Activa','Inactiva') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `bodega`
--

INSERT INTO `bodega` (`Id_Bodega`, `Nombre_Bodega`, `Ubicacion`, `Estado`) VALUES
(1, 'Ubicacion 1', 'Nariño Principal', 'Activa'),
(2, 'Ubicacion 2', 'Nariño Ppal', 'Activa'),
(9, 'Ubicacion 3', 'El Rosario', 'Activa'),
(13, 'Ubicacion 4', 'Pasto', 'Activa'),
(14, 'Ubicacion 5', 'La Cruz', 'Activa'),
(15, 'Ubicacion 6', 'La Cruz', 'Activa'),
(16, 'Ubicacion 7', 'Bogota D.C.', 'Inactiva');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `Id_cliente` int(11) NOT NULL,
  `No_NIT` int(11) NOT NULL,
  `Nombre_Cliente` varchar(45) NOT NULL,
  `Ciudad` varchar(45) NOT NULL,
  `Direccion` varchar(45) NOT NULL,
  `No_Telefono` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Estado` enum('Activo','Suspendido','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Id_cliente`, `No_NIT`, `Nombre_Cliente`, `Ciudad`, `Direccion`, `No_Telefono`, `Email`, `Estado`) VALUES
(1, 56789098, 'Orlando Moreno', 'Bogota D.C.', 'El Estero Cra. 7 No. 8-75 Sur', '312587985', 'omoreno@gmail.com', 'Activo'),
(2, 25856558, 'Sonfia Nuñez', 'Pasto', 'El Saldo Calle 3 No. 15-18', '312354451', 'sofianuñez85@hotmail.com', 'Activo'),
(3, 2147483647, 'Alberto Pinilla', 'Pasto', 'Cra 15 No. 12-34', '2147483647', 'albertop@gmail.com', 'Activo'),
(8, 63334176, 'Doris Patiño', 'Pasto', 'Cra18 No. 15-24', '2147483647', 'dorispatino@gmail.com', 'Activo'),
(9, 1010107586, 'Sara Rodriguez', 'Bogota D.C.', 'Cra 12 No 25-54', '312456789', 'sararodrig@homail.com', 'Activo'),
(10, 1023789456, 'Carlos Beltran', 'Bogota D.C.', 'Calle 68 No. 15-54', '2147483647', 'carlosbeltran@hotmail.com', 'Activo'),
(11, 2147483647, 'Carlos Cardenas', 'Bogota D.C.', 'Cra 58-478', '312456789', 'carloscardenas@gmail.com', 'Suspendido');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_egreso`
--

CREATE TABLE `detalle_egreso` (
  `Id_Detalle_Egreso` int(11) NOT NULL,
  `Id_Egreso` int(11) NOT NULL,
  `Id_cliente` int(11) NOT NULL,
  `ID_Bodega` int(11) NOT NULL,
  `ID_Producto` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `PVP` double NOT NULL,
  `Subtotal_Egreso` double NOT NULL,
  `IVA_Egreso` double NOT NULL,
  `Total_Egreso` double NOT NULL,
  `Costo_Unitario` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `detalle_egreso`
--

INSERT INTO `detalle_egreso` (`Id_Detalle_Egreso`, `Id_Egreso`, `Id_cliente`, `ID_Bodega`, `ID_Producto`, `Cantidad`, `PVP`, `Subtotal_Egreso`, `IVA_Egreso`, `Total_Egreso`, `Costo_Unitario`) VALUES
(2, 2, 0, 1, 9, 7, 0, 0, 0, 0, NULL),
(3, 3, 0, 2, 9, 6, 0, 0, 0, 0, NULL),
(4, 4, 0, 1, 9, 1, 0, 0, 0, 0, NULL),
(5, 5, 0, 1, 10, 1, 0, 0, 0, 0, NULL),
(6, 6, 0, 1, 10, 1, 0, 0, 0, 0, NULL),
(10, 15, 1, 1, 10, 1, 0, 0, 0, 0, NULL),
(11, 16, 2, 1, 10, 1, 4, 0, 0, 0, NULL),
(12, 17, 2, 1, 10, 1, 4, 0, 0, 0, NULL),
(17, 22, 2, 2, 10, 1, 4, 0, 0, 0, NULL),
(18, 23, 1, 1, 9, 1, 14, 0, 0, 0, NULL),
(19, 23, 1, 1, 11, 2, 3.5, 0, 0, 0, NULL),
(20, 24, 2, 1, 9, 1, 14, 0, 0, 0, NULL),
(21, 24, 2, 1, 12, 1, 5, 0, 0, 0, NULL),
(22, 25, 2, 1, 10, 8, 4, 0, 0, 0, NULL),
(23, 26, 2, 1, 10, 7, 4, 0, 0, 0, NULL),
(24, 27, 1, 1, 9, 7, 14, 0, 0, 0, NULL),
(25, 28, 1, 1, 10, 5, 4, 0, 0, 0, NULL),
(26, 29, 1, 1, 9, 10, 14, 0, 0, 0, NULL),
(27, 34, 0, 1, 10, 10, 4000, 0, 0, 0, NULL),
(28, 35, 0, 1, 10, 10, 4000, 0, 0, 0, NULL),
(29, 35, 0, 1, 11, 10, 3500, 0, 0, 0, NULL),
(30, 36, 0, 1, 10, 1, 4000, 0, 0, 0, NULL),
(31, 37, 0, 1, 10, 5, 4000, 0, 0, 0, NULL),
(32, 37, 0, 1, 11, 10, 3500, 0, 0, 0, NULL),
(35, 42, 0, 1, 12, 3, 5000, 0, 0, 0, 3500.00),
(36, 45, 0, 1, 12, 2, 5000, 0, 0, 0, 3500.00),
(38, 51, 0, 1, 12, 2, 5000, 10000, 0, 0, NULL),
(39, 52, 0, 1, 12, 4, 5000, 0, 0, 0, 3500.00),
(40, 53, 0, 1, 12, 2, 5000, 10000, 0, 0, NULL),
(41, 54, 0, 1, 9, 10, 14000, 0, 0, 0, 3700.00),
(42, 55, 0, 1, 9, 2, 14000, 28000, 0, 0, NULL),
(43, 56, 0, 1, 12, 2, 5000, 10000, 0, 0, NULL),
(44, 57, 0, 1, 12, 4, 5000, 0, 0, 0, 3500.00),
(45, 58, 0, 1, 12, 4, 5000, 0, 0, 0, 3500.00),
(46, 59, 0, 1, 12, 2, 5000, 0, 0, 0, 3500.00),
(47, 60, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(48, 61, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(49, 62, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(50, 63, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(51, 64, 0, 1, 9, 2, 14000, 0, 0, 0, 3700.00),
(52, 65, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(53, 66, 0, 1, 9, 1, 14000, 14000, 0, 0, NULL),
(54, 67, 0, 1, 9, 2, 14000, 0, 0, 0, 3721.74),
(55, 67, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(56, 68, 0, 1, 9, 1, 14000, 0, 0, 0, 3721.74),
(57, 68, 0, 1, 12, 1, 5000, 0, 0, 0, 3500.00),
(58, 69, 0, 1, 9, 1, 14000, 14000, 0, 0, NULL),
(59, 70, 0, 1, 9, 1, 14000, 14000, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ingreso`
--

CREATE TABLE `detalle_ingreso` (
  `ID_Detalle_Ingreso` int(11) NOT NULL,
  `ID_Ingreso` int(11) NOT NULL,
  `ID_Proveedor` int(45) NOT NULL,
  `ID_Producto` int(11) NOT NULL,
  `ID_Bodega` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Costo_Unitario` double NOT NULL,
  `Subtotal_Ingreso` double NOT NULL,
  `IVA_Ingreso` double NOT NULL,
  `Total_Ingreso` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `detalle_ingreso`
--

INSERT INTO `detalle_ingreso` (`ID_Detalle_Ingreso`, `ID_Ingreso`, `ID_Proveedor`, `ID_Producto`, `ID_Bodega`, `Cantidad`, `Costo_Unitario`, `Subtotal_Ingreso`, `IVA_Ingreso`, `Total_Ingreso`) VALUES
(1, 6, 0, 9, 1, 10, 4.5, 0, 0, 0),
(2, 7, 0, 9, 1, 5, 7800, 0, 0, 0),
(3, 8, 0, 9, 1, 12, 3500, 0, 0, 0),
(4, 9, 0, 12, 1, 20, 3500, 0, 0, 0),
(5, 10, 0, 9, 1, 10, 3500, 0, 0, 0),
(6, 11, 0, 10, 1, 10, 3500, 0, 0, 0),
(7, 12, 0, 11, 1, 10, 3800, 0, 0, 0),
(8, 12, 0, 9, 1, 5, 2800, 0, 0, 0),
(9, 13, 0, 10, 1, 2, 5200, 0, 0, 0),
(10, 14, 0, 15, 1, 10, 3500, 0, 0, 0),
(11, 15, 0, 9, 1, 5, 3500, 0, 0, 0),
(12, 16, 0, 16, 2, 25, 4500, 0, 0, 0),
(13, 17, 0, 9, 1, 50, 3700, 0, 0, 0),
(14, 18, 0, 9, 1, 10, 3800, 0, 0, 0),
(15, 19, 0, 20, 1, 20, 3500, 0, 0, 0),
(16, 19, 0, 19, 1, 20, 2800, 0, 0, 0),
(17, 19, 0, 16, 1, 50, 4300, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_nota`
--

CREATE TABLE `detalle_nota` (
  `ID_Detalle` int(11) NOT NULL,
  `nota_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `bodega_id` int(11) NOT NULL,
  `Cantidad` decimal(10,2) NOT NULL,
  `Costo_Unitario` decimal(10,2) NOT NULL,
  `Subtotal_Item` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `egreso_producto`
--

CREATE TABLE `egreso_producto` (
  `Id_Egreso` int(11) NOT NULL,
  `Tipo_Egreso` enum('Factura','Ajuste','Nota de Crédito','Nota de Débito') NOT NULL,
  `Factura_Referencia_Id` int(11) NOT NULL,
  `Id_cliente` int(11) NOT NULL,
  `Fecha_Egreso` date NOT NULL,
  `Subtotal_Egreso` decimal(10,2) NOT NULL,
  `Descuento_Aplicado` decimal(10,2) DEFAULT 0.00,
  `IVA_Egreso` decimal(10,2) NOT NULL,
  `Total_Egreso` decimal(10,2) NOT NULL,
  `Num_Documento` varchar(20) DEFAULT NULL,
  `Id_Usuario` int(11) NOT NULL,
  `Costo_Mercancia_Vendida` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Motivo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `egreso_producto`
--

INSERT INTO `egreso_producto` (`Id_Egreso`, `Tipo_Egreso`, `Factura_Referencia_Id`, `Id_cliente`, `Fecha_Egreso`, `Subtotal_Egreso`, `Descuento_Aplicado`, `IVA_Egreso`, `Total_Egreso`, `Num_Documento`, `Id_Usuario`, `Costo_Mercancia_Vendida`, `Motivo`) VALUES
(1, 'Factura', 0, 2, '2025-06-18', 0.00, 0.00, 0.00, 116620.00, NULL, 0, 0.00, NULL),
(2, 'Factura', 0, 2, '2025-06-18', 0.00, 0.00, 0.00, 116620.00, NULL, 0, 0.00, NULL),
(3, '', 0, 1, '2025-06-18', 0.00, 0.00, 0.00, 99960.00, NULL, 0, 0.00, NULL),
(4, '', 0, 1, '2025-06-18', 0.00, 0.00, 0.00, 16660.00, NULL, 0, 0.00, NULL),
(5, '', 0, 1, '2025-08-11', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(6, '', 0, 2, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(7, '', 0, 2, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(8, '', 0, 2, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(9, '', 0, 1, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(10, '', 0, 1, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(11, '', 0, 2, '2025-08-11', 14.00, 0.00, 3.00, 16.66, NULL, 0, 0.00, NULL),
(12, '', 0, 1, '2025-08-11', 4.00, 0.00, 66500.00, 4.17, NULL, 0, 0.00, NULL),
(13, '', 0, 1, '2025-08-11', 4.00, 0.00, 66500.00, 4.17, NULL, 0, 0.00, NULL),
(14, '', 0, 3, '2025-08-11', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(15, '', 0, 1, '2025-08-11', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(16, '', 0, 2, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(17, 'Factura', 0, 2, '2025-08-11', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(18, 'Factura', 0, 1, '2025-08-13', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(19, 'Factura', 0, 2, '2025-08-13', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(20, 'Factura', 0, 3, '2025-08-13', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(21, 'Factura', 0, 2, '2025-08-13', 0.00, 0.00, 0.00, 0.00, NULL, 0, 0.00, NULL),
(22, 'Factura', 0, 2, '2025-08-12', 4.00, 0.00, 0.00, 4.17, NULL, 0, 0.00, NULL),
(23, 'Factura', 0, 1, '2025-08-23', 21.00, 0.00, 0.00, 24.99, NULL, 0, 0.00, NULL),
(24, 'Factura', 0, 2, '2025-08-23', 19.00, 0.00, 0.00, 22.61, NULL, 0, 0.00, NULL),
(25, 'Factura', 0, 2, '2025-08-23', 32.00, 0.00, 6.00, 38.08, NULL, 0, 0.00, NULL),
(26, 'Factura', 0, 2, '2025-08-23', 28.00, 0.00, 5.00, 33.32, NULL, 0, 0.00, NULL),
(27, 'Factura', 0, 1, '2025-08-23', 98.00, 0.00, 18.62, 116.62, NULL, 0, 0.00, NULL),
(28, 'Factura', 0, 1, '2025-08-23', 20000.00, 0.00, 3800.00, 23800.00, NULL, 0, 0.00, NULL),
(29, 'Factura', 0, 1, '2025-08-23', 140.00, 0.00, 26.60, 166.60, NULL, 0, 0.00, NULL),
(30, 'Factura', 0, 1, '2025-08-23', 21000.00, 0.00, 3990.00, 24990.00, NULL, 0, 0.00, NULL),
(31, 'Factura', 0, 2, '2025-08-23', 98000.00, 0.00, 18620.00, 116620.00, NULL, 0, 0.00, NULL),
(32, 'Factura', 0, 1, '2025-08-23', 40000.00, 0.00, 7600.00, 47600.00, NULL, 0, 0.00, NULL),
(33, 'Factura', 0, 2, '2025-08-23', 60000.00, 0.00, 11400.00, 71400.00, NULL, 0, 0.00, NULL),
(34, 'Factura', 0, 1, '2025-08-23', 40000.00, 0.00, 7600.00, 47600.00, NULL, 0, 0.00, NULL),
(35, 'Factura', 0, 1, '2025-08-25', 75000.00, 0.00, 14250.00, 89250.00, NULL, 0, 0.00, NULL),
(36, 'Ajuste', 0, 1, '2025-08-27', 4000.00, 0.00, 760.00, 4760.00, NULL, 0, 0.00, NULL),
(37, 'Factura', 0, 11, '2025-08-28', 55000.00, 0.00, 10450.00, 65450.00, NULL, 0, 0.00, NULL),
(42, 'Factura', 0, 2, '2025-11-30', 15000.00, 0.00, 2850.00, 17850.00, NULL, 0, 10500.00, NULL),
(45, 'Factura', 0, 1, '2025-12-01', 10000.00, 0.00, 1900.00, 11900.00, NULL, 0, 7000.00, NULL),
(51, 'Factura', 45, 1, '2025-12-04', 10000.00, 0.00, 1900.00, 11900.00, NULL, 1, 0.00, NULL),
(52, 'Factura', 0, 1, '2025-12-03', 20000.00, 0.00, 3800.00, 23800.00, NULL, 0, 14000.00, NULL),
(53, 'Nota de Crédito', 52, 1, '2025-12-04', 10000.00, 0.00, 1900.00, 11900.00, 'NC-0001', 1, 0.00, 'Devolucionb'),
(54, 'Factura', 0, 3, '2025-12-03', 140000.00, 0.00, 26600.00, 166600.00, NULL, 0, 37000.00, NULL),
(55, 'Nota de Crédito', 54, 3, '2025-12-04', 28000.00, 0.00, 5320.00, 33320.00, 'NC-0002', 1, 0.00, 'Devolucion'),
(56, 'Nota de Crédito', 51, 1, '2025-12-08', 10000.00, 0.00, 1900.00, 11900.00, 'NC-0003', 1, 0.00, 'Devolucion'),
(57, 'Factura', 0, 1, '2025-12-08', 0.00, 0.00, 3420.00, 21420.00, NULL, 0, 14000.00, NULL),
(58, 'Factura', 0, 1, '2025-12-08', 0.00, 0.00, 3420.00, 21420.00, NULL, 0, 14000.00, NULL),
(59, 'Factura', 0, 1, '2025-12-08', 9000.00, 1000.00, 1710.00, 10710.00, NULL, 0, 7000.00, NULL),
(60, 'Factura', 0, 1, '2025-12-09', 5000.00, 0.00, 950.00, 5950.00, NULL, 0, 3500.00, NULL),
(61, 'Factura', 0, 2, '2025-12-09', 5000.00, 0.00, 950.00, 5950.00, NULL, 0, 3500.00, NULL),
(62, 'Factura', 0, 3, '2025-12-09', 5000.00, 0.00, 950.00, 5950.00, NULL, 0, 3500.00, NULL),
(63, 'Factura', 0, 8, '2025-12-09', 5000.00, 0.00, 950.00, 5950.00, NULL, 0, 3500.00, NULL),
(64, 'Factura', 0, 3, '2025-12-10', 26000.00, 2000.00, 4940.00, 30940.00, NULL, 0, 7400.00, NULL),
(65, 'Factura', 0, 1, '2025-12-10', 5000.00, 0.00, 950.00, 5950.00, NULL, 0, 3500.00, NULL),
(66, 'Nota de Crédito', 64, 3, '2025-12-11', 14000.00, 0.00, 2660.00, 16660.00, 'NC-0004', 1, 0.00, 'Devolucion por caducidad'),
(67, 'Factura', 0, 1, '2025-12-15', 33000.00, 0.00, 6270.00, 39270.00, NULL, 0, 10943.48, NULL),
(68, 'Factura', 0, 1, '2025-12-15', 18000.00, 1000.00, 3420.00, 21420.00, NULL, 0, 7221.74, NULL),
(69, 'Nota de Crédito', 68, 1, '2025-12-16', 14000.00, 0.00, 2660.00, 16660.00, 'NC-0005', 1, 0.00, 'Devolucion'),
(70, 'Nota de Crédito', 64, 3, '2026-02-08', 14000.00, 0.00, 2660.00, 16660.00, 'NC-0006', 1, 0.00, 'Devolucioin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingreso_producto`
--

CREATE TABLE `ingreso_producto` (
  `ID_Ingreso` int(11) NOT NULL,
  `Tipo_Ingreso` enum('Orden de Compra','Ajuste x Inventario','Ajuste x Produccion') NOT NULL,
  `ID_Proveedor` int(11) NOT NULL,
  `No_Doc_Proveedor` int(11) NOT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `Estado` enum('Pendiente','Grabado','Anulado') NOT NULL,
  `Subtotal` decimal(10,2) NOT NULL,
  `IVA` decimal(10,2) NOT NULL,
  `Total` decimal(10,2) NOT NULL,
  `Fecha_Creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `motivo_anulacion` varchar(255) DEFAULT NULL,
  `fecha_anulacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `ingreso_producto`
--

INSERT INTO `ingreso_producto` (`ID_Ingreso`, `Tipo_Ingreso`, `ID_Proveedor`, `No_Doc_Proveedor`, `Fecha_Ingreso`, `Estado`, `Subtotal`, `IVA`, `Total`, `Fecha_Creacion`, `motivo_anulacion`, `fecha_anulacion`) VALUES
(5, 'Orden de Compra', 1, 10003, '2025-04-02', 'Grabado', 0.00, 0.00, 0.00, '2025-06-17 00:00:00', NULL, NULL),
(6, 'Orden de Compra', 1, 5245845, '2025-06-18', 'Pendiente', 45.00, 8.55, 53.55, '2025-06-18 21:58:24', NULL, NULL),
(7, 'Orden de Compra', 1, 85987254, '2025-06-18', 'Pendiente', 39000.00, 7410.00, 46410.00, '2025-06-18 23:19:32', NULL, NULL),
(8, 'Orden de Compra', 1, 587874, '2025-08-10', 'Pendiente', 42000.00, 7980.00, 49980.00, '2025-08-10 18:00:24', NULL, NULL),
(9, 'Orden de Compra', 1, 586854, '2025-08-10', 'Pendiente', 70000.00, 13300.00, 83300.00, '2025-08-10 18:24:06', NULL, NULL),
(10, 'Orden de Compra', 2, 5898758, '2025-08-11', 'Pendiente', 35000.00, 6650.00, 41650.00, '2025-08-11 21:07:10', NULL, NULL),
(11, 'Orden de Compra', 1, 45789825, '2025-08-20', 'Pendiente', 35000.00, 6650.00, 41650.00, '2025-08-20 21:52:03', NULL, NULL),
(12, 'Orden de Compra', 1, 45789825, '2025-08-27', 'Pendiente', 52000.00, 9880.00, 61880.00, '2025-08-27 19:10:56', NULL, NULL),
(13, 'Orden de Compra', 1, 857889, '2025-08-27', 'Pendiente', 10400.00, 1976.00, 12376.00, '2025-08-27 22:23:32', NULL, NULL),
(14, 'Orden de Compra', 1, 987654, '2025-08-28', 'Pendiente', 35000.00, 6650.00, 41650.00, '2025-08-28 22:13:37', NULL, NULL),
(15, 'Orden de Compra', 1, 2123456, '2025-11-01', 'Anulado', 17500.00, 3325.00, 20825.00, '2025-11-30 21:31:51', 'Error en costo de entrada', '2025-11-30 22:22:08'),
(16, 'Orden de Compra', 1, 587895, '2025-12-01', 'Anulado', 112500.00, 21375.00, 133875.00, '2025-11-30 21:33:10', 'Error en el costo unitario.', '2025-11-30 22:18:09'),
(17, 'Orden de Compra', 1, 254788, '2025-12-03', 'Pendiente', 185000.00, 35150.00, 220150.00, '2025-12-03 22:48:52', NULL, NULL),
(18, 'Orden de Compra', 1, 858456, '2025-12-10', 'Pendiente', 38000.00, 7220.00, 45220.00, '2025-12-10 20:45:03', NULL, NULL),
(19, 'Orden de Compra', 7, 859652, '2025-12-01', 'Pendiente', 341000.00, 64790.00, 405790.00, '2025-12-15 17:09:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `ID_Producto` int(11) NOT NULL,
  `ID_Bodega` int(11) NOT NULL,
  `Stock` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Costo_promedio` decimal(10,2) NOT NULL DEFAULT 0.00,
  `Stock_Minimo` decimal(10,2) DEFAULT 0.00,
  `Stock_Optimo` decimal(10,2) DEFAULT 0.00,
  `Fecha_Actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`ID_Producto`, `ID_Bodega`, `Stock`, `Costo_promedio`, `Stock_Minimo`, `Stock_Optimo`, `Fecha_Actualizacion`) VALUES
(9, 1, 42.00, 3721.74, 0.00, 0.00, '2026-02-08 19:31:39'),
(9, 2, 8.00, 0.00, 0.00, 0.00, '2025-12-16 00:52:26'),
(11, 1, 0.00, 0.00, 0.00, 0.00, '2025-12-01 02:28:50'),
(12, 1, 1.00, 3500.00, 0.00, 0.00, '2025-12-16 00:49:40'),
(16, 1, 50.00, 4300.00, 0.00, 0.00, '2025-12-15 22:09:22'),
(16, 2, 0.00, 0.00, 0.00, 0.00, '2025-12-01 03:18:09'),
(19, 1, 20.00, 2800.00, 0.00, 0.00, '2025-12-15 22:09:22'),
(20, 1, 20.00, 3500.00, 0.00, 0.00, '2025-12-15 22:09:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `id_modulo` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `carpeta` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento_inventario`
--

CREATE TABLE `movimiento_inventario` (
  `ID_Movimiento` int(11) NOT NULL,
  `ID_Producto` int(11) NOT NULL,
  `ID_Bodega_Origen` int(11) DEFAULT NULL,
  `ID_Bodega_Destino` int(11) DEFAULT NULL,
  `Tipo_Movimiento` enum('Transferencia','Ajuste','Compra','Venta') NOT NULL,
  `Cantidad` decimal(10,2) NOT NULL,
  `Fecha_Movimiento` datetime NOT NULL,
  `Motivo` varchar(255) DEFAULT NULL,
  `ID_Usuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `movimiento_inventario`
--

INSERT INTO `movimiento_inventario` (`ID_Movimiento`, `ID_Producto`, `ID_Bodega_Origen`, `ID_Bodega_Destino`, `Tipo_Movimiento`, `Cantidad`, `Fecha_Movimiento`, `Motivo`, `ID_Usuario`) VALUES
(1, 9, 1, 2, 'Transferencia', -2.00, '2025-12-08 05:38:07', '0', 5),
(2, 9, 1, 2, 'Transferencia', 2.00, '2025-12-08 05:38:07', '0', 5),
(3, 9, 1, 2, 'Transferencia', -2.00, '2025-12-11 02:43:53', '0', 1),
(4, 9, 1, 2, 'Transferencia', 2.00, '2025-12-11 02:43:53', '0', 1),
(5, 9, 1, 2, 'Transferencia', -4.00, '2025-12-16 01:52:25', '0', 1),
(6, 9, 1, 2, 'Transferencia', 4.00, '2025-12-16 01:52:25', '0', 1),
(7, 9, NULL, 1, 'Ajuste', 1.00, '2026-02-08 00:00:00', 'Ajuste producto perdida', 1),
(8, 10, NULL, 1, 'Ajuste', 2.00, '2026-02-08 00:00:00', 'Ajuste producto perdida', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento_kardex`
--

CREATE TABLE `movimiento_kardex` (
  `ID_Movimiento` int(11) NOT NULL,
  `ID_Producto` int(11) NOT NULL COMMENT 'Clave foránea a la tabla producto',
  `ID_Bodega` int(11) NOT NULL COMMENT 'Clave foránea a la tabla bodega',
  `Fecha_Movimiento` datetime NOT NULL,
  `Tipo_Documento` varchar(50) NOT NULL,
  `ID_Documento` int(11) NOT NULL COMMENT 'ID de la factura, ingreso o nota que origina el movimiento',
  `Tipo_Movimiento` varchar(10) NOT NULL COMMENT 'ENTRADA o SALIDA',
  `Cantidad_Entrada` decimal(10,2) DEFAULT 0.00,
  `Costo_Entrada` decimal(10,2) DEFAULT 0.00,
  `Cantidad_Salida` decimal(10,2) DEFAULT 0.00,
  `Costo_Salida` decimal(10,2) DEFAULT 0.00,
  `Stock_Final` decimal(10,2) NOT NULL,
  `Costo_Promedio_Final` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `movimiento_kardex`
--

INSERT INTO `movimiento_kardex` (`ID_Movimiento`, `ID_Producto`, `ID_Bodega`, `Fecha_Movimiento`, `Tipo_Documento`, `ID_Documento`, `Tipo_Movimiento`, `Cantidad_Entrada`, `Costo_Entrada`, `Cantidad_Salida`, `Costo_Salida`, `Stock_Final`, `Costo_Promedio_Final`) VALUES
(1, 12, 1, '2025-12-02 05:01:16', '0', 45, 'SALIDA', 0.00, 0.00, 2.00, 3500.00, 16.00, 3500.00),
(2, 12, 1, '2025-12-04 04:36:36', '0', 52, 'SALIDA', 0.00, 0.00, 4.00, 3500.00, 14.00, 3500.00),
(3, 9, 1, '2025-12-04 04:49:43', '0', 54, 'SALIDA', 0.00, 0.00, 10.00, 3700.00, 40.00, 3700.00),
(4, 12, 1, '2025-12-09 04:45:28', '0', 57, 'SALIDA', 0.00, 0.00, 4.00, 3500.00, 14.00, 3500.00),
(5, 12, 1, '2025-12-09 04:45:29', '0', 58, 'SALIDA', 0.00, 0.00, 4.00, 3500.00, 10.00, 3500.00),
(6, 12, 1, '2025-12-09 04:53:44', '0', 59, 'SALIDA', 0.00, 0.00, 2.00, 3500.00, 8.00, 3500.00),
(7, 12, 1, '2025-12-10 04:59:04', '0', 60, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 7.00, 3500.00),
(8, 12, 1, '2025-12-10 05:12:25', '0', 61, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 6.00, 3500.00),
(9, 12, 1, '2025-12-10 05:48:12', '0', 62, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 5.00, 3500.00),
(10, 12, 1, '2025-12-10 05:53:49', '0', 63, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 4.00, 3500.00),
(11, 9, 1, '2025-12-11 02:40:43', '0', 64, 'SALIDA', 0.00, 0.00, 2.00, 3700.00, 38.00, 3700.00),
(12, 12, 1, '2025-12-11 03:04:13', '0', 65, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 3.00, 3500.00),
(13, 9, 1, '2025-12-15 22:44:25', '0', 67, 'SALIDA', 0.00, 0.00, 2.00, 3721.74, 45.00, 3721.74),
(14, 12, 1, '2025-12-15 22:44:25', '0', 67, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 2.00, 3500.00),
(15, 9, 1, '2025-12-16 01:49:40', '0', 68, 'SALIDA', 0.00, 0.00, 1.00, 3721.74, 44.00, 3721.74),
(16, 12, 1, '2025-12-16 01:49:40', '0', 68, 'SALIDA', 0.00, 0.00, 1.00, 3500.00, 1.00, 3500.00),
(17, 9, 1, '2026-02-08 00:00:00', 'NOTA_AJUSTE', 3, '0', 0.00, 9500.00, 1.00, 9500.00, 19.00, 9500.00),
(18, 10, 1, '2026-02-08 00:00:00', 'NOTA_AJUSTE', 3, '0', 0.00, 3000.00, 2.00, 3000.00, 28.00, 3000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota_ajuste`
--

CREATE TABLE `nota_ajuste` (
  `ID_Nota` int(11) NOT NULL,
  `tipo_nota` varchar(20) NOT NULL,
  `fecha_nota` date NOT NULL,
  `no_factura_referencia` varchar(50) NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `iva` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `nota_ajuste`
--

INSERT INTO `nota_ajuste` (`ID_Nota`, `tipo_nota`, `fecha_nota`, `no_factura_referencia`, `id_proveedor`, `subtotal`, `iva`, `total`, `usuario_id`, `fecha_creacion`) VALUES
(3, 'AJUSTE_SALIDA', '2026-02-08', '', NULL, 0.00, 0.00, 0.00, 1, '2026-02-08 20:42:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(100) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expira` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE `perfiles` (
  `id_perfil` int(10) UNSIGNED NOT NULL,
  `nombre_perfil` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`id_perfil`, `nombre_perfil`, `descripcion`, `estado`) VALUES
(1, 'Administracion', 'Permisos generales del sistema, parametrización de usuarios y acceso general a modulos.', 'activo'),
(2, 'Compras', 'Permisos al módulo de abastecimiento e inventarios', 'activo'),
(3, 'Ventas', 'Acceso a modulos de ventas', 'activo'),
(4, 'Logistica', 'Acceso a modulos de Inventarios', 'activo'),
(5, 'Contabilidad', 'Acceso a los moduloso contables y costos.', 'activo'),
(6, 'Personal', 'Acceso a los moduoos de recuros humanos y nomina', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil_permiso`
--

CREATE TABLE `perfil_permiso` (
  `id_perfil` int(10) UNSIGNED NOT NULL,
  `id_permiso` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos`
--

CREATE TABLE `permisos` (
  `id_permiso` int(10) UNSIGNED NOT NULL,
  `modulo` varchar(60) NOT NULL,
  `accion` enum('ver','crear','editar','eliminar','anular','') NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `permisos`
--

INSERT INTO `permisos` (`id_permiso`, `modulo`, `accion`, `descripcion`) VALUES
(1, 'Usuarios', 'ver', 'Permite ver los usuarios registrados'),
(2, 'Usuarios', 'crear', 'Permite crear nuevos usuarios'),
(3, 'Usuarios', 'editar', 'Permite editar usuarios existentes'),
(4, 'Usuarios', 'eliminar', 'Permite eliminar usuarios'),
(5, 'Configuración', 'ver', 'Permite ver la configuración del sistema'),
(6, 'Configuración', 'editar', 'Permite modificar la configuración del sistema'),
(7, 'Proveedores', 'ver', 'Permite ver los proveedores'),
(8, 'Proveedores', 'crear', 'Permite registrar proveedores'),
(9, 'Proveedores', 'editar', 'Permite editar proveedores'),
(10, 'Proveedores', 'eliminar', 'Permite eliminar proveedores'),
(11, 'Compras y Ajustes', 'ver', 'Permite ver las compras registradas'),
(12, 'Compras y Ajustes', 'crear', 'Permite registrar nuevas compras'),
(13, 'Compras y Ajustes', 'editar', 'Permite modificar compras existentes'),
(14, 'Compras y Ajustes', 'anular', 'Permite anular compras'),
(15, 'Anulaciones', 'ver', 'Permite ver documentos anulados'),
(16, 'Anulaciones', 'anular', 'Permite anular documentos'),
(17, 'Clientes', 'ver', 'Permite ver clientes registrados'),
(18, 'Clientes', 'crear', 'Permite crear nuevos clientes'),
(19, 'Clientes', 'editar', 'Permite editar clientes'),
(20, 'Clientes', 'eliminar', 'Permite eliminar clientes'),
(21, 'Facturación', 'ver', 'Permite ver facturas emitidas'),
(22, 'Facturación', 'crear', 'Permite emitir nuevas facturas'),
(23, 'Facturación', 'editar', 'Permite modificar facturas existentes'),
(24, 'Facturación', 'anular', 'Permite anular facturas'),
(25, 'Notas Débito y Crédito', 'ver', 'Permite ver notas de débito y crédito'),
(26, 'Notas Débito y Crédito', 'crear', 'Permite crear nuevas notas'),
(27, 'Notas Débito y Crédito', 'editar', 'Permite editar notas existentes'),
(28, 'Notas Débito y Crédito', '', 'Permite anular notas'),
(29, 'Stocks', 'ver', 'Permite ver los stocks de productos'),
(30, 'Stocks', '', 'Permite realizar ajustes de stock'),
(31, 'Productos', 'ver', 'Permite ver productos'),
(32, 'Productos', 'crear', 'Permite registrar productos'),
(33, 'Productos', 'editar', 'Permite modificar productos'),
(34, 'Productos', 'eliminar', 'Permite eliminar productos'),
(35, 'Bodegas', 'ver', 'Permite ver bodegas'),
(36, 'Bodegas', 'crear', 'Permite crear nuevas bodegas'),
(37, 'Bodegas', 'editar', 'Permite editar bodegas existentes'),
(38, 'Bodegas', 'eliminar', 'Permite eliminar bodegas'),
(39, 'Ajustes de Inventario', 'ver', 'Permite ver ajustes de inventario'),
(40, 'Ajustes de Inventario', 'crear', 'Permite registrar ajustes de inventario'),
(41, 'Ajustes de Inventario', 'editar', 'Permite modificar ajustes de inventario'),
(42, 'Ajustes de Inventario', 'eliminar', 'Permite eliminar ajustes de inventario'),
(43, 'Reportes', 'ver', 'Permite ver todos los reportes del sistema');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `ID_Producto` int(11) NOT NULL,
  `ID_Proveedor` int(11) NOT NULL,
  `Nombre_Producto` varchar(45) NOT NULL,
  `Tipo` enum('Mercancia','Insumos','Suministros','Muebles y Enseres') NOT NULL,
  `Categoria` enum('Helados','Lacteos','Yogurt','') NOT NULL,
  `Und_Empaque` enum('Unidad','x10','x12','x24') NOT NULL,
  `Ruta_Imagen` varchar(100) NOT NULL,
  `Stock` int(45) DEFAULT 0,
  `Stock_Minimo` int(45) DEFAULT 0,
  `Stock_Optimo` int(45) DEFAULT 0,
  `Costo_Unitario` double DEFAULT 0,
  `PVP` double NOT NULL,
  `ID_Bodega` int(11) NOT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT 'Activo',
  `Marca` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ID_Producto`, `ID_Proveedor`, `Nombre_Producto`, `Tipo`, `Categoria`, `Und_Empaque`, `Ruta_Imagen`, `Stock`, `Stock_Minimo`, `Stock_Optimo`, `Costo_Unitario`, `PVP`, `ID_Bodega`, `Estado`, `Marca`) VALUES
(9, 1, 'Copo Helado 150gr', 'Mercancia', 'Helados', 'x10', 'public/img/productos/prod_693794c2b7c7f4.55470978.png', 19, 10, 20, 9500, 14000, 1, 'Activo', 'Crem Helado'),
(10, 1, 'Helado Supremo 100gr', 'Mercancia', 'Helados', 'x10', 'public/img/productos/prod_693794d502d3f6.73197497.png', 28, 10, 20, 3000, 5000, 1, 'Activo', 'Crem Helado'),
(11, 1, 'Helado Supremo 70gr', 'Mercancia', 'Helados', 'x10', 'public/img/productos/prod_693794e0dc2f39.02326048.png', 50, 10, 20, 2500, 3500, 1, 'Activo', 'Crem Helado'),
(12, 1, 'Cono Super 100gr', 'Mercancia', 'Helados', 'Unidad', 'public/img/productos/prod_693794fb355ea0.87931437.png', 10, 10, 20, 3500, 5000, 1, 'Activo', 'Topsy'),
(13, 2, 'Chocobanano 150gr', 'Mercancia', 'Helados', 'Unidad', 'public/img/productos/prod_69379510412230.18869345.png', 8, 10, 20, 7500, 15000, 1, 'Activo', 'Crem Helado'),
(14, 2, 'Helado Festin 100gr', 'Mercancia', 'Helados', 'Unidad', 'public/img/productos/prod_69379533ceb3c1.48071844.png', 0, 0, 0, 4500, 8000, 1, 'Activo', 'La Especial'),
(15, 4, 'Cremoso Yogoso 200gr', 'Mercancia', 'Helados', 'Unidad', 'public/img/productos/prod_6937955f9b8d63.92184156.jpg', 0, 0, 0, 2000, 3500, 1, 'Activo', 'La Especial'),
(16, 2, 'Helado Heladin 120gr', 'Mercancia', 'Helados', 'x10', 'public/img/productos/prod_69379580198669.16842459.png', 0, 0, 0, 2500, 3500, 1, 'Activo', 'La Especial'),
(17, 2, 'Helado Cremoso Super Heladin', 'Mercancia', 'Helados', 'Unidad', 'public/img/productos/prod_693795918f5901.56554939.png', 0, 0, 0, 5000, 7000, 1, 'Activo', 'Crem Helado'),
(19, 3, 'Casero La Especial 80gr', 'Insumos', 'Helados', 'x10', 'public/img/productos/prod_6936281323ca28.50548017.jpg', 0, 0, 0, 1500, 2500, 1, 'Activo', 'La Especial'),
(20, 7, 'Helado Framberry', 'Mercancia', 'Helados', 'x10', 'public/img/productos/prod_69408423c18028.54062629.png', 0, 0, 0, 3800, 5000, 1, 'Activo', 'La Especial'),
(21, 4, 'Helado Cremoso 150gr', 'Mercancia', 'Helados', 'x10', 'public/img/productos/prod_6940ae302c62d6.70363842.png', 0, 0, 0, 4500, 5800, 2, 'Activo', 'Yogoso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `ID_Proveedor` int(11) NOT NULL,
  `No_NIT` int(11) NOT NULL,
  `Nombre_Proveedor` varchar(45) NOT NULL,
  `Ciudad` varchar(45) NOT NULL,
  `Direccion` varchar(45) NOT NULL,
  `Tel_Contacto` int(11) NOT NULL,
  `Asesor_Contacto` varchar(45) NOT NULL,
  `Productos_Venta` text NOT NULL,
  `Estado` enum('Activo','Suspendido') DEFAULT 'Activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Proveedores';

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`ID_Proveedor`, `No_NIT`, `Nombre_Proveedor`, `Ciudad`, `Direccion`, `Tel_Contacto`, `Asesor_Contacto`, `Productos_Venta`, `Estado`) VALUES
(1, 91247010, 'Industrias lacteas S.A.S', 'Bogota D.C', 'Cdra 70D No. 48-54 Sur', 547896, 'Orlando Moreno', 'Leche, Helados, Yogurt', 'Activo'),
(2, 56789098, 'Industrias Alimenticias Heladin', 'Medellin', 'Cra 23 No. 34-56', 304567890, 'Eduardo Maldonado', 'Helado, Queso, Yogurt, Leche', 'Activo'),
(3, 67890456, 'Industrias Persy', 'Bogota D.C.', 'Cra 45 No. 12-67', 302456543, 'Alicia Barragan', 'Helado, Queso, Yogurt, Leche', 'Activo'),
(4, 58985758, 'Helados Robin Hood', 'Pasto Nariño', 'Cra 18 No. 35-45', 214748365, 'Pepito Jimenez', 'Helado, Yogurt', 'Activo'),
(7, 45789789, 'Helados Don Tebi', 'Bogota D.C.', 'Cra 12 45-45', 305789456, 'Domingo Cardenas', 'Helados, Yogurt', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `ID_reporte` int(11) NOT NULL,
  `ID_usuario` int(11) NOT NULL,
  `Tipo_reporte` varchar(45) NOT NULL,
  `Fecha_reporte` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `id_perfil` int(100) NOT NULL,
  `no_identificacion` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `ciudad` varchar(45) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `cargo` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `Estado` enum('Activo','Suspendido','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Usuarios del Sistema';

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `id_perfil`, `no_identificacion`, `nombre`, `apellido`, `ciudad`, `direccion`, `telefono`, `cargo`, `email`, `contrasena`, `Estado`) VALUES
(1, 1, 1023861067, 'Edward Herrera', '', 'Pasto Nariño', 'Cra 26D No. 35C-30 Sur', '301456789', 'Administrador', 'pepito@hotmail.com', '$2y$10$IyH7CuVfH1kXGY.285v.oeSthNQ6Bc0PTd9MqOji.NxhWhEA5ydRK', 'Activo'),
(2, 3, 1010175086, 'Viviana Herrera Caballero', '', 'Bogota', 'Calle 43A Sur No. 12A-55', '318525607', 'Asesor', 'pepita@gmail.com', '$2y$10$oiKWM4ocgZpLwB16CSX7QOaeq/W1cxsGckpdY2Hro4FK5W0Gx/qkC', 'Activo'),
(5, 4, 67889096, 'Maria Alejandra Guerrero', '', 'Bogota DC. Colombia', 'Calle 45 No. 15-56', '302345678', 'Operario', 'mague17@gmail.com', '$2y$10$GULjMY9rf4Gn.6rkbV4aze4q5ybhmOhXC3Jzx/1YWEuasSZFpQs/q', 'Activo'),
(7, 2, 79123456, 'Andres Orozco', '', 'Bogota DC. Colombia', 'Cra 12 No. 54-65 Sur', '301987654', 'Jefe De Compras', 'aorozco@gmail.com', '$2y$10$lozP77x6H9oRfhaIs1u5ZO7vnnkecHH5S.XvJ1BukyoxEtIaHqUCG', 'Activo'),
(8, 1, 1025896478, 'Alejandra Palacios', '', 'La Cruz Nariño', 'Calle 5 No. 4-54', '3126756345', 'Directora', 'apalacios@gmail.com', '$2y$10$cwnTJK2hCft5pUmkRPi33uwHD4X68l.2WYowfXBpJso6xkZkEXR4y', 'Activo'),
(11, 2, 25879456, 'Alberto Soriano', '', 'Pasto Nariño', 'cra 18 No. 12-34', '321456789', 'Analista', 'ablertosorinano45@gmail.com', '$2y$10$wbi.OkZbFvZmACyCqsP.IeKhSTWFMQm30QfbhuGN/zsUGvP5A8lCO', 'Activo'),
(12, 3, 924994767, 'Lia Cardenas', '', 'Guayaquil', 'Mapasingue Oeste Av. 2da #222 y Calle 2da', '0996746638', 'Jefe', 'lia_isabel14@hotmail.com', '$2y$10$EJ2fLLvKW7jhyVk5Nx7H3.ZBARD3BlDw7Ks9z09VzGtVx.YO4Doi.', 'Activo'),
(13, 1, 907824684, 'Carlos Cardenas', '', 'Bogota DC. Colombia', 'Cra 68 No. 13-54', '304567896', 'Gerente General', 'carlos.cardenas.macias@gmail.com', '$2y$10$89pcQGJoFoQlN84K.LwSuu/kfDwNV9PzIXk0z.MhibuWBENCZ0KGG', 'Activo'),
(14, 4, 65789855, 'Orlando Caballero', '', 'La Cruz', 'Cra 7 noi. 8-25', '312456789', 'Operario', 'orlandocaballero@gmail.comn', '$2y$10$ITs6az.b1UUL0uQibjbmG.tJ6iuYAjl.ZWeuFjinl1GpCJPnU9/m.', 'Activo'),
(15, 4, 78958785, 'Orlando Jimenez', '', 'Pasto', 'Cra 45-85-78', '312456789', 'Operario', 'orlandojimenez@gmai.com', '$2y$10$Q7pe0FS9xaN.VcntnCgFAe4dgx/qN0Q8cwt84cLdXDT8PaEsG5fqi', 'Suspendido'),
(16, 2, 1023789456, 'Alberto Garcia', '', 'Bogota', 'Cra 68 No 15-24', '312456799', 'Asistente', 'agarcia@gmail.com', '$2y$10$aHOw6Rsc/KlxLL.2wUE/aOSMqU3orYNiHiOxu60a6jekAQh46zVvG', 'Suspendido');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_backup`
--

CREATE TABLE `usuarios_backup` (
  `id_usuario` int(11) NOT NULL DEFAULT 0,
  `id_perfil` int(100) NOT NULL,
  `no_identificacion` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `ciudad` varchar(45) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `cargo` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `Estado` enum('Activo','Inactivo','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios_backup`
--

INSERT INTO `usuarios_backup` (`id_usuario`, `id_perfil`, `no_identificacion`, `nombre`, `apellido`, `ciudad`, `direccion`, `telefono`, `cargo`, `email`, `contrasena`, `Estado`) VALUES
(1, 1, 1023861067, 'Edward Herrera', '', 'Pasto Nariño', 'Cra 26D No. 35C-30 Sur', '301456789', 'Administrador', 'pepito@hotmail.com', '$2y$10$IyH7CuVfH1kXGY.285v.oeSthNQ6Bc0PTd9MqOji.NxhWhEA5ydRK', 'Activo'),
(2, 3, 1010175086, 'Viviana Caballero', '', 'Bogota', 'Calle 43A Sur No. 12A-55', '318525607', 'Asesor', 'pepita@gmail.com', '$2y$10$IpJOdn.IIiuh2rf35s8FRex0M9fAoXqNXO91W3ZXjtdrf9FBZltCO', 'Activo'),
(5, 4, 67889096, 'Maria Alejandra Guerrero', '', 'Bogota DC. Colombia', 'Calle 45 No. 15-56', '302345678', 'Operario', 'mague17@gmail.com', '$2y$10$y6dnGoNOil7JU0v2VgTF8Ocl1j.RDh9Q0PsMhQfcnm36CXnsY.ad6', 'Activo'),
(7, 2, 79123456, 'Andres Orozco', '', 'Bogota DC. Colombia', 'Cra 12 No. 54-65 Sur', '301987654', 'Jefe De Compras', 'aorozco@gmail.com', '$2y$10$dVmGc6hSSIg1k48iT8i8Ve/pIMu.dpiYOAQ.yVfrqcrlYGBMDtu.e', 'Activo'),
(8, 1, 1025896478, 'Alejandra Castillo', '', 'La Cruz Nariño', 'Calle 5 no. 4-54', '3126756345', 'Directora', 'acastillo@gmail.com', '$2y$10$87AbwOjKj9xqWBNpmrfWzORphoJXlzfvHTXaObUGyECK0GW.xWTvC', 'Activo'),
(11, 2, 25879456, 'Alberto Soriano', '', 'Pasto Nariño', 'cra 18 No. 12-34', '321456789', 'Analista', 'ablertosorinano45@gmail.com', '$2y$10$ArV1eOhFqoerj4tD04CmxesXrAcCQsyZO9kMq4uk3G8fdXED7ly9q', 'Activo'),
(12, 3, 924994767, 'Lia Cardenas', '', 'Guayaquil', 'Mapasingue Oeste Av. 2da #222 y Calle 2da', '0996746638', 'Jefe', 'lia_isabel14@hotmail.com', '$2y$10$uimOqMwhEKcDYmVnES8fv.YYStbczwL1rd8QVlpo6BrRDD6j465/u', 'Activo'),
(13, 1, 907824684, 'Carlos Cardenas', '', 'Bogota DC. Colombia', 'Cra 68 No. 13-54', '304567896', 'Gerente General', 'carlos.cardenas.macias@gmail.com', '$2y$10$6NbbEnotEavu2M4uE4agXeZ66ECoJWWIr6Rn5wX53DPSzacPK0Sdu', 'Activo'),
(14, 4, 65789855, 'Orlando Caballero', '', 'La Cruz', 'Cra 7 noi. 8-25', '312456789', 'Operario', 'orlandocaballero@gmail.comn', '$2y$10$3UGggs673VAm6tRTZZ0Qj.XMNTv3Fr5xAMIZtq9cdQJ.iebAK4H32', 'Activo'),
(15, 4, 78958785, 'Orlando Jimenez', '', 'Pasto', 'Cra 45-85-78', '312456789', 'Operario', 'orlandojimenez@gmai.com', '$2y$10$m/gaUfc8PnuTD2Oa1Y9G2uZr/MedmmHYmEJ14y6ckv/PhAwE2G/7S', 'Activo'),
(16, 2, 1023789456, 'Alberto Garcia', '', 'Bogota', 'Cra 68 No 15-24', '312456799', 'Asistente', 'agarcia@gmail.com', '$2y$10$xgLn3fOLQb5ztzYT0LSWR.vqEnbQ/SEIHd4t9n40anQOSBROMT8ia', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bodega`
--
ALTER TABLE `bodega`
  ADD PRIMARY KEY (`Id_Bodega`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`Id_cliente`);

--
-- Indices de la tabla `detalle_egreso`
--
ALTER TABLE `detalle_egreso`
  ADD PRIMARY KEY (`Id_Detalle_Egreso`),
  ADD KEY `No_Factura` (`Id_Egreso`),
  ADD KEY `Cod_producto` (`ID_Producto`),
  ADD KEY `Cod_Bodega` (`ID_Bodega`),
  ADD KEY `Id_cliente` (`Id_cliente`);

--
-- Indices de la tabla `detalle_ingreso`
--
ALTER TABLE `detalle_ingreso`
  ADD PRIMARY KEY (`ID_Detalle_Ingreso`),
  ADD KEY `No_Ingreso` (`ID_Ingreso`),
  ADD KEY `Cod_producto` (`ID_Producto`),
  ADD KEY `ID_Bodega` (`ID_Bodega`);

--
-- Indices de la tabla `detalle_nota`
--
ALTER TABLE `detalle_nota`
  ADD PRIMARY KEY (`ID_Detalle`);

--
-- Indices de la tabla `egreso_producto`
--
ALTER TABLE `egreso_producto`
  ADD PRIMARY KEY (`Id_Egreso`),
  ADD KEY `Cod_cliente` (`Id_cliente`);

--
-- Indices de la tabla `ingreso_producto`
--
ALTER TABLE `ingreso_producto`
  ADD PRIMARY KEY (`ID_Ingreso`),
  ADD KEY `Cod_Proveedor` (`ID_Proveedor`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`ID_Producto`,`ID_Bodega`),
  ADD UNIQUE KEY `idx_producto_bodega` (`ID_Producto`,`ID_Bodega`),
  ADD KEY `ID_Bodega` (`ID_Bodega`);

--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`id_modulo`);

--
-- Indices de la tabla `movimiento_inventario`
--
ALTER TABLE `movimiento_inventario`
  ADD PRIMARY KEY (`ID_Movimiento`),
  ADD KEY `ID_Producto` (`ID_Producto`),
  ADD KEY `ID_Bodega_Origen` (`ID_Bodega_Origen`),
  ADD KEY `ID_Bodega_Destino` (`ID_Bodega_Destino`),
  ADD KEY `ID_Usuario` (`ID_Usuario`);

--
-- Indices de la tabla `movimiento_kardex`
--
ALTER TABLE `movimiento_kardex`
  ADD PRIMARY KEY (`ID_Movimiento`);

--
-- Indices de la tabla `nota_ajuste`
--
ALTER TABLE `nota_ajuste`
  ADD PRIMARY KEY (`ID_Nota`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id_perfil`),
  ADD UNIQUE KEY `nombre` (`nombre_perfil`);

--
-- Indices de la tabla `perfil_permiso`
--
ALTER TABLE `perfil_permiso`
  ADD PRIMARY KEY (`id_perfil`,`id_permiso`),
  ADD KEY `fk_pp_permiso` (`id_permiso`);

--
-- Indices de la tabla `permisos`
--
ALTER TABLE `permisos`
  ADD PRIMARY KEY (`id_permiso`),
  ADD UNIQUE KEY `uniq_permiso` (`modulo`,`accion`),
  ADD KEY `idx_modulo` (`modulo`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`ID_Producto`),
  ADD KEY `Proveedor_Principal` (`ID_Proveedor`),
  ADD KEY `ID_Bodega` (`ID_Bodega`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`ID_Proveedor`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`ID_reporte`),
  ADD KEY `ID_usuario` (`ID_usuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `No_Identificacion_3` (`no_identificacion`),
  ADD KEY `No_Identificacion` (`no_identificacion`),
  ADD KEY `No_Identificacion_2` (`no_identificacion`),
  ADD KEY `perfiles` (`id_perfil`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bodega`
--
ALTER TABLE `bodega`
  MODIFY `Id_Bodega` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `Id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `detalle_egreso`
--
ALTER TABLE `detalle_egreso`
  MODIFY `Id_Detalle_Egreso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT de la tabla `detalle_ingreso`
--
ALTER TABLE `detalle_ingreso`
  MODIFY `ID_Detalle_Ingreso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `detalle_nota`
--
ALTER TABLE `detalle_nota`
  MODIFY `ID_Detalle` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `egreso_producto`
--
ALTER TABLE `egreso_producto`
  MODIFY `Id_Egreso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT de la tabla `ingreso_producto`
--
ALTER TABLE `ingreso_producto`
  MODIFY `ID_Ingreso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `modulos`
--
ALTER TABLE `modulos`
  MODIFY `id_modulo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento_inventario`
--
ALTER TABLE `movimiento_inventario`
  MODIFY `ID_Movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `movimiento_kardex`
--
ALTER TABLE `movimiento_kardex`
  MODIFY `ID_Movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `nota_ajuste`
--
ALTER TABLE `nota_ajuste`
  MODIFY `ID_Nota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `id_perfil` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `permisos`
--
ALTER TABLE `permisos`
  MODIFY `id_permiso` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `ID_Producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `ID_Proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `reportes`
--
ALTER TABLE `reportes`
  MODIFY `ID_reporte` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_egreso`
--
ALTER TABLE `detalle_egreso`
  ADD CONSTRAINT `detalle_egreso_ibfk_1` FOREIGN KEY (`Id_producto`) REFERENCES `producto` (`ID_Producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `detalle_egreso_ibfk_2` FOREIGN KEY (`Id_Egreso`) REFERENCES `egreso_producto` (`Id_Egreso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `detalle_egreso_ibfk_3` FOREIGN KEY (`ID_Bodega`) REFERENCES `bodega` (`Id_Bodega`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detalle_ingreso`
--
ALTER TABLE `detalle_ingreso`
  ADD CONSTRAINT `detalle_ingreso_ibfk_1` FOREIGN KEY (`ID_Producto`) REFERENCES `producto` (`ID_Producto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `detalle_ingreso_ibfk_2` FOREIGN KEY (`ID_Ingreso`) REFERENCES `ingreso_producto` (`ID_Ingreso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `detalle_ingreso_ibfk_3` FOREIGN KEY (`ID_Bodega`) REFERENCES `bodega` (`Id_Bodega`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `egreso_producto`
--
ALTER TABLE `egreso_producto`
  ADD CONSTRAINT `egreso_producto_ibfk_1` FOREIGN KEY (`Id_cliente`) REFERENCES `cliente` (`Id_cliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ingreso_producto`
--
ALTER TABLE `ingreso_producto`
  ADD CONSTRAINT `ingreso_producto_ibfk_2` FOREIGN KEY (`ID_Proveedor`) REFERENCES `proveedor` (`ID_Proveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`ID_Producto`) REFERENCES `producto` (`ID_Producto`),
  ADD CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`ID_Bodega`) REFERENCES `bodega` (`Id_Bodega`);

--
-- Filtros para la tabla `movimiento_inventario`
--
ALTER TABLE `movimiento_inventario`
  ADD CONSTRAINT `movimiento_inventario_ibfk_1` FOREIGN KEY (`ID_Producto`) REFERENCES `producto` (`ID_Producto`),
  ADD CONSTRAINT `movimiento_inventario_ibfk_2` FOREIGN KEY (`ID_Bodega_Origen`) REFERENCES `bodega` (`Id_Bodega`),
  ADD CONSTRAINT `movimiento_inventario_ibfk_3` FOREIGN KEY (`ID_Bodega_Destino`) REFERENCES `bodega` (`Id_Bodega`),
  ADD CONSTRAINT `movimiento_inventario_ibfk_4` FOREIGN KEY (`ID_Usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `perfil_permiso`
--
ALTER TABLE `perfil_permiso`
  ADD CONSTRAINT `fk_pp_perfil` FOREIGN KEY (`id_perfil`) REFERENCES `perfiles` (`id_perfil`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pp_permiso` FOREIGN KEY (`id_permiso`) REFERENCES `permisos` (`id_permiso`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_3` FOREIGN KEY (`ID_Bodega`) REFERENCES `bodega` (`Id_Bodega`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `producto_ibfk_4` FOREIGN KEY (`ID_Proveedor`) REFERENCES `proveedor` (`ID_Proveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
